## Django & React DEMO

This is a Django project with a React front-end.

The REST API is created with Django REST framework and consumed with Axios.

Check out [Django React Tutorial with Example Demo](https://www.techiediaries.com/django-react-rest/)

## The CustomerList Component

![](https://screenshotscdn.firefoxusercontent.com/images/b6c13999-6cdf-4ed1-9dca-557072912320.png)


## The CustomerCreateUpdate Component

![](https://screenshotscdn.firefoxusercontent.com/images/b499804f-6807-4897-8950-e2a26ff2d745.png)
