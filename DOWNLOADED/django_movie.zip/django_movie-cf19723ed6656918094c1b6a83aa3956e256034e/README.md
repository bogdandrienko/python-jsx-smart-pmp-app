<p align="center">
    <a href="https://djangochannel.com" target="_blank" rel="noopener noreferrer">
        <img width="100" src="logo.png" title="djangoschool">
    </a>
</p>

<h2 align="center">Django Movie</h2>

[Сайт](https://djangochannel.com)
[YouTube](https://www.youtube.com/channel/UC_hPYclmFCIENpMUHpPY8FQ?view_as=subscriber)

Кинобиблиотека на Django 3.

Проект написан в рамках обучающего курса по Django 3 на youtube.

- Категории
- Жанры
- Фильмы
- Кадры из фильма
- Режиссеры\Актеры
- Звезды рейтинга
- Отзывы
- Фильтры


